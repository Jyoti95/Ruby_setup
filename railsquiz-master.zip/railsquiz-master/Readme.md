# Rails quiz app

Created by [Juliana Peña](http://julianapena.com)
Free under [Ms-PL](http://www.opensource.org/licenses/MS-PL)

## Usage

**Run app:**
rails server

**Edit questions:**
Go to http://localhost:3000/questions

**Take quiz:**
Go to http://localhost:3000/quiz/index