# ITESM CEM, May 11, 2011.
# Ruby Source File
# Activity::  Final Project: Design Patterns Quiz App
# Author::    1165536 Juliana Pena

# Load the rails application
require File.expand_path('../application', __FILE__)

# Initialize the rails application
Quizapp::Application.initialize!
