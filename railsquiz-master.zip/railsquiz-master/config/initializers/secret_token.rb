# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Quizapp::Application.config.secret_token = 'd37305dd9df86348e533ba74b3a8f6d53ea4084c4c05ccd8317bc47ff8fa6fe0cd29e0610fb83b1901ca940d102e06f70b0fb7213793410b7d1902232408e2eb'
