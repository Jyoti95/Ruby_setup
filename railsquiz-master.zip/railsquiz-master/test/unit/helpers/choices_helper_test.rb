require 'test_helper'

class ChoicesHelperTest < ActionView::TestCase
end
